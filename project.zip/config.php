<?php

// $host = "dbhost.cs.man.ac.uk"; // change when using ;
// $username_db = "m17832wa";
// $password = "Zulu7Tutorial";
// $db_name = "2021_comp10120_z7";

$host = "localhost"; // change when using ;
$username_db = "master";
$password = "root";
$db_name = "2021_comp10120_z7";

?>
